"""Build the Markdown/HTML report and static plots from retained browser timings."""
from pathlib import Path
import json, statistics as st, csv, html, base64, sys
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

out=Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
data=json.loads((out/'results.json').read_text())
meta=data['metadata']
groups={c['name']:[r for r in data['results'] if r['name']==c['name']] for c in data['cases']}
assert all(len(v)==meta['rounds'] for v in groups.values()), 'Incomplete benchmark run'
def med(name, mode): return st.median(r[mode]['medianMs'] for r in groups[name])
def delta(name): return med(name,'on')-med(name,'off')
def pct(name): return 100*delta(name)/med(name,'off')
def stats(name): return groups[name][0]['on']
def f(x): return f'{x:.2f}'
def timing(name): return f"{f(med(name,'off'))} → {f(med(name,'on'))} ms (+{f(delta(name))} ms)"

with (out/'summary.csv').open('w',newline='') as file:
 w=csv.writer(file); w.writerow(['scenario','records','characters','definition_characters','off_ms','on_ms','added_ms','added_percent','prefixes','text_candidates','extra_index_requests','extra_raw_rows','intermediate_matches'])
 for c in data['cases']:
  n=c['name']; s=stats(n)
  w.writerow([n,c['n'],len(c['text']),c['bytes'],med(n,'off'),med(n,'on'),delta(n),pct(n),s['prefixes'],s['groups'],s['requests'],s['rawRows'],s['generatedMatches']])

plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'axes.labelcolor':'#344354','text.color':'#142c42','axes.edgecolor':'#9aaabd','xtick.color':'#46566a','ytick.color':'#46566a','figure.facecolor':'white','axes.facecolor':'white','svg.fonttype':'none'})
blue='#1264a3'; green='#14816b'; orange='#bd6517'; gray='#697b8a'
def clean(ax):
 ax.grid(axis='y',color='#e1e8ef',linewidth=.7); ax.set_axisbelow(True); ax.set_ylim(bottom=0)
def series(ax, names, xs, mode, color, label):
 ys=[med(n,mode) for n in names]
 lo=[min(r[mode]['medianMs'] for r in groups[n]) for n in names]
 hi=[max(r[mode]['medianMs'] for r in groups[n]) for n in names]
 ax.plot(xs,ys,'o-',color=color,lw=2,label=label,markersize=5)
 ax.fill_between(xs,lo,hi,color=color,alpha=.11)
def save(fig,name):
 fig.savefig(out/(name+'.png'),dpi=180,bbox_inches='tight');fig.savefig(out/(name+'.svg'),bbox_inches='tight');plt.close(fig)

fig,axs=plt.subplots(1,2,figsize=(12,4.7),layout='constrained')
fig.suptitle('Entry count: small groups first, heavier cases separately',fontsize=16,fontweight='bold')
for ax,ns,title in zip(axs,[[0,1,3,5,10,20],[0,1,3,5,10,20,50,100]],['Focus: 0–20 records sharing one prefix','Sensitivity check: up to 100 records']):
 names=[f'prefix-{n}' for n in ns]
 series(ax,names,ns,'off',gray,'Feature off');series(ax,names,ns,'on',blue,'Feature on')
 ax.set(title=title,xlabel='Records sharing the literal prefix X',ylabel='Core lookup time (ms)');clean(ax);ax.set_xticks([0,5,10,15,20] if len(ns)==6 else [0,20,50,100]);ax.legend(loc='upper left',frameon=False)
fig.supxlabel('22-character input • 1 KiB definition per pattern • JMdict background • bands show five-round range',fontsize=9)
save(fig,'entry-count')

fig,ax=plt.subplots(figsize=(10,4),layout='constrained')
ns=[0,1,3,5,10,20,50,100];names=[f'prefix-{n}' for n in ns]
vals=[delta(n) for n in names]
ax.bar(range(len(ns)),vals,color=[blue]*6+[orange]*2,width=.62)
for i,(n,y) in enumerate(zip(names,vals)): ax.text(i,y+.035,f'+{y:.2f} ms\n+{pct(n):.0f}%',ha='center',va='bottom',fontsize=9)
ax.set_xticks(range(len(ns)),ns);ax.set(xlabel='Records sharing one prefix (categories, not a continuous scale)',ylabel='Added lookup time (ms)',title='Performance drag = enabled time minus disabled time');clean(ax);ax.set_ylim(top=max(vals)*1.35)
save(fig,'entry-drag')

fig,axs=plt.subplots(1,2,figsize=(12,4.8),layout='constrained')
fig.suptitle('Practical factors with only five candidate records',fontsize=16,fontweight='bold')
lengths=[16,32,64,96];names=[f'length-{l}-n5' for l in lengths]
series(axs[0],names,lengths,'off',gray,'Off, 5 patterns')
series(axs[0],names,lengths,'on',blue,'On, 5 patterns')
series(axs[0],[f'length-{l}-n0' for l in lengths],lengths,'on',green,'On, no patterns')
axs[0].set(title='Longer scans: prefixes of one Japanese sentence',xlabel='Scanned characters',ylabel='Core lookup time (ms)',xticks=lengths);clean(axs[0]);axs[0].legend(frameon=False)
xs=[0,1,2,3];names=[f'definition-{b}' for b in [256,1024,5120,20480]]
series(axs[1],names,xs,'off',gray,'Feature off');series(axs[1],names,xs,'on',blue,'Feature on')
axs[1].set(title='Larger definitions: 22-character input',xlabel='ASCII definition content per record (categories)',ylabel='Core lookup time (ms)',xticks=xs);axs[1].set_xticklabels(['256 B','1 KiB','5 KiB','20 KiB']);clean(axs[1]);axs[1].legend(frameon=False)
fig.supxlabel('Native IndexedDB • medians of five rounds • bands show round-to-round range, not confidence intervals',fontsize=9)
save(fig,'practical-factors')

md=[]; body=[]
def p(ident,text):
 md.append(f'{ident}. {text}\n');body.append(f'<p id="{ident}"><span class="pid">{ident}</span> {html.escape(text)}</p>')
def table(headers,rows):
 md.append('| '+' | '.join(headers)+' |\n| '+' | '.join(['---']*len(headers))+' |\n'+'\n'.join('| '+' | '.join(map(str,r))+' |' for r in rows)+'\n')
 body.append('<div class="table-wrap"><table><thead><tr>'+''.join('<th>'+html.escape(h)+'</th>' for h in headers)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+html.escape(str(c))+'</td>' for c in r)+'</tr>' for r in rows)+'</tbody></table></div>')
def figure(name,caption):
 md.append(f'![{caption}](grammar-wildcards-performance/{name}.png)\n')
 encoded=base64.b64encode((out/(name+'.png')).read_bytes()).decode()
 body.append(f'<figure><img src="data:image/png;base64,{encoded}" alt="{html.escape(caption)}"><figcaption>{html.escape(caption)}</figcaption></figure>')

p('R-1','This report measures how the optional Japanese ～ matcher changes lookup time. The main experiment covers 0–20 records sharing one exact prefix, then extends to 50 and 100 as heavier sensitivity checks. These are chosen test ranges, not measured distributions of real grammar dictionaries. Hundreds or thousands of patterns under a specific prefix such as 費用が～ should not be treated as normal use.')
p('R-2',f"Main finding: with five shared-prefix records, lookup measured {timing('prefix-5')}. At 20 records it measured {timing('prefix-20')}; at 100, {timing('prefix-100')}. The feature also has a cost when no pattern is found: {timing('prefix-0')}. The small-N curve is mostly flat within run-to-run variation. These results do not establish a reliable extra cost per added entry. Absolute milliseconds are more useful here than a large percentage over a short baseline.")
p('R-3','What N means: N separate dictionary records whose expression begins with 費用が～. This is not the total dictionary size, the number of distinct prefixes, or the number of ordinary words beginning with 費用が. Each nonzero case has one matching pattern, 費用が～かかる; the remaining controlled patterns have endings that fail to match. Multiple definitions inside one glossary still count as one record. Copies stored as separate records count separately.')
p('R-4','The fixed input is 費用が予想していた金額よりもかなり多くかかる (22 characters). Each test pattern has 1,024 ASCII definition characters. Every new experiment retains 314,984 real JMdict term records as background data. Those background records contain no supported interior ～ patterns. They exercise ordinary indexed lookup, but this setup does not represent every dictionary collection.')
figure('entry-count','F-1. Total lookup time versus records sharing a prefix. The left panel focuses on small counts; the right extends the same experiment to 100. Shaded bands show the minimum and maximum round medians.')
table(['Shared-prefix records N','Off (ms)','On (ms)','Added (ms)','Added time (%)'],[[n,f(med(f'prefix-{n}','off')),f(med(f'prefix-{n}','on')),f(delta(f'prefix-{n}')),f'{pct(f"prefix-{n}"):.0f}%'] for n in ns])
figure('entry-drag','F-2. Added time and percentage increase over the disabled case. The orange bars are heavier sensitivity checks. Bar positions are categories, not equal numeric intervals.')
p('R-5',f"How to read the curve: even at N=0, this input causes {stats('prefix-0')['requests']} extra index requests. More records then add retrieval, string comparisons, and result work. The lower measured value at N=1 than N=0 does not mean that adding an entry makes lookup faster. Small differences between neighboring points may come from timing noise; do not infer a precise per-entry coefficient. Relative drag means (on − off) / off × 100. For example, +100% time means twice the lookup time, not the same metric as a −100% CodSpeed efficiency change.")
p('R-6','Why the cost grows: the implementation builds candidate text forms and their prefixes, queries the expression and reading indexes, loads full rows, and then tests the pattern endings. It compares returned records with every distinct text candidate. For this input, the wildcard step builds '+str(stats('prefix-5')['prefixes'])+' unique prefixes and examines '+str(stats('prefix-5')['groups'])+' text candidates. A longer literal prefix helps only when it excludes the input. A failed ending does not avoid the row read.')
figure('practical-factors','F-3. Scan length and definition size with only five candidate records. The scan test truncates one natural Japanese sentence; the definition-size test holds the input and pattern count fixed.')
p('R-7',f"Scan length deserves attention before very large prefix groups. With five nonmatching patterns, the 16-character scan measured {timing('length-16-n5')}; the 96-character scan measured {timing('length-96-n5')}. Enabled lookup with no wildcard records also rises from {f(med('length-16-n0','on'))} to {f(med('length-96-n0','on'))} ms. Longer text creates more ordinary candidates as well as more wildcard prefixes and requests. The current scan-length default is 16; reaching a distant closing literal requires a longer scan. The 96-character case represents deliberately extended scanning, not the default.")
table(['Scan length','Off, N=5 (ms)','On, N=5 (ms)','Added (ms)','Extra index requests'],[[l,f(med(f'length-{l}-n5','off')),f(med(f'length-{l}-n5','on')),f(delta(f'length-{l}-n5')),stats(f'length-{l}-n5')['requests']] for l in lengths])
p('R-8','The scan-control sentence is: 費用が当初の見積もりでは十分に考慮されていなかった建物の老朽化に伴う追加工事や資材の値上がりに加えて、専門の業者に依頼するための交通費や宿泊費まで含めると、私たちが去年の会議で予想していた金額よりもはるかに多くかかる。 The test takes its first 16, 32, 64, or 96 characters. All five pattern endings deliberately fail, so this isolates scanning cost without changing the number of successful wildcard results.')
p('R-9',f"Definition size is a secondary factor at small N. For five records, moving from 256 characters to 20,480 characters per definition changed enabled time from {f(med('definition-256','on'))} to {f(med('definition-20480','on'))} ms. The latter means roughly 100 KiB of ASCII definition content across five rows. These sizes model compact versus detailed articles; they are not measured percentiles of grammar dictionaries. The timing bands overlap strongly, so this run does not establish a clear size effect at five records. The experiment measures text retrieval, not structured-layout cost or image loading. The much larger earlier payload stress test should not substitute for these small-N results.")
p('R-10','Other plausible factors at five records: several dictionaries may repeat a pattern; a record may match both expression and reading indexes; and a dictionary may be disabled while another stays enabled. The controls below keep the same 22-character input and 1 KiB definition size. They show the size of each case locally, not a universal ranking. Their off baselines also vary slightly between runs.')
factors=[('No matching endings','no-matches-5'),('One matching record','prefix-5'),('Five matching records / repeated pattern','all-match-5'),('Same five matches in both indexes','both-indexes-5'),('Five rows in a disabled dictionary','disabled-5'),('100 patterns with unrelated prefixes','unrelated-100')]
table(['Scenario','Off (ms)','On (ms)','Added (ms)','Extra rows read'],[[label,f(med(n,'off')),f(med(n,'on')),f(delta(n)),stats(n)['rawRows']] for label,n in factors])
p('R-11','Interpretation: matching both indexes can read one row twice, while filtering later prevents duplicate candidate IDs. Disabled dictionaries can still incur reads because dictionary filtering happens after retrieval. Unrelated prefixes do not return those pattern rows. Dictionary count alone is therefore a weak predictor; the matching records, their sizes, and their index hits matter more. Five repeated records are a plausible way to model copies across dictionaries; thousands of copies are only an adversarial test.')
p('R-12','Natural grammar examples use five patterns: せっかく～のに, せっかく～ても, せっかく～けれども, せっかく～だから, and せっかく～なら. The examples below vary length and wording together, so they illustrate complete inputs rather than isolate one cause. The repeated-ending sentence offers two valid のに endpoints. A long gap is not an exponential search: the matcher checks literal pieces without recursive backtracking.')
natural=[('Short','natural-5-short'),('Long clause','natural-5-long'),('Two のに endings','natural-5-repeated')]
table(['Example','Characters','Off (ms)','On (ms)','Added (ms)','Intermediate wildcard matches'],[[label,len(groups[n][0]['text']),f(med(n,'off')),f(med(n,'on')),f(delta(n)),stats(n)['generatedMatches']] for label,n in natural])
for i,(label,n) in enumerate(natural,13): p(f'R-{i}',label+': '+groups[n][0]['text'])
p('R-16','Factors not isolated here: conjugation, kana normalization, and custom replacement rules can create more text candidates. Scanning many words in quick succession repeats the lookup cost. Popup rendering, grouping, frequency dictionaries, and rich definitions can add user-visible delay after the measured core work. Older phones, other browsers, cold database reads, or competing tabs can behave differently. No numeric multiplier is assigned to these unmeasured factors.')
p('R-17','Practical priorities: first reduce the extra prefix construction and empty index queries, since they affect common lookups with few or no patterns. Then measure typical rich grammar articles and repeated patterns before choosing a larger cache or index redesign. Loading pattern metadata before definitions, routing candidates by prefix, and using an ID map for repeated results are possible improvements. The experiments do not prove that an internal database redesign is necessary for ordinary small-N use. The disabled feature bypasses this extra search path.')
p('R-18','Earlier stress results are retained only as a separate scale check. Those experiments used an otherwise empty term store and different definition sizes, so their absolute timings must not be joined to the new curve. They expose limits; they do not predict typical user experience.')
old=json.loads((out/'stress-results.json').read_text()); oldmap={r['name']:r for r in old['results']}
stress=[('1,000 same-prefix misses; 32-character definitions','same-prefix-1000'),('10,000 same-prefix misses; 32-character definitions','same-prefix-10000'),('3,000 duplicate patterns; eight matching endings','repeated-ending-3000')]
table(['Synthetic stress case','Off (ms)','On (ms)'],[[label,f(oldmap[n]['off']['medianMs']),f(oldmap[n]['on']['medianMs'])] for label,n in stress])
p('R-19',f"Method: commit {meta['commit'][:8]}; {meta['cpu']}; {meta['browser'].split('HeadlessChrome/')[-1].split(' ')[0]} Chromium; native IndexedDB; Node {meta['node']}. Each scenario runs in five rounds, with deterministic shuffled scenario order. Each round has eight warm-up off/on pairs and 21 timed pairs, alternating which mode runs first. The plotted value is the median of the five round medians (105 measured lookups per mode). Bands show the range of those five medians, not a confidence interval. Work counters come from a separate instrumented lookup outside the timed samples.")
p('R-20','Scope: Japanese exact lookup, letter search resolution, deinflection enabled, simple result mode, and no frequency sorting. The benchmark directly calls the production Translator and DictionaryDatabase. It loads JMdict term rows into their internal field format, bypassing import UI, and keeps that background enabled. It uses a fresh isolated browser context and stubs only the unused media worker. Import, extension messaging, page scanning, popup rendering, and cold-start delay are excluded. These are local diagnostics, not a Playwright UI pass or CodSpeed CI result. No runtime code changed for this report.')
p('R-21',f"Reproduction: evidence.zip contains measure.mjs, generate.py, raw results with every timing sample, summary.csv, and the earlier stress results. From the repository root, unzip the evidence into a temporary directory, run node /path/to/measure.mjs /path/to/jmdict_english.zip, then python3 /path/to/generate.py /path/to/output. The harness needs this checkout's Node dependencies and Playwright Chromium; the plot script needs Python with matplotlib and numpy. The JMdict fixture has revision {meta['dictionaryIndex']['revision']} and SHA-256 {meta['dictionarySha256']}. The dictionary itself is not bundled. HTML embeds its plots and can be shared as one file.")
md.append('R-22. Artifacts: [HTML report](grammar-wildcards-performance/report.html), [CSV data](grammar-wildcards-performance/summary.csv), [reproduction bundle](grammar-wildcards-performance/evidence.zip).\n')
md.append('R-23. Code references: [wildcard candidate lookup](../../ext/js/language/translator.js#L431), [dictionary filtering](../../ext/js/dictionary/dictionary-database.js#L288), [bulk index requests](../../ext/js/dictionary/dictionary-database.js#L620), [matcher](../../ext/js/language/grammar-wildcard.js#L25), [scan-length default](../../ext/data/schemas/options-schema.json#L776).\n')
(out.parent/'grammar-wildcards-performance.md').write_text('# Optional grammar wildcards: performance report\n\n'+'\n'.join(md))
css='''body{margin:0;background:#edf2f6;color:#20384b;font:16px/1.65 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}main{max-width:1080px;margin:36px auto;background:white;padding:48px 56px;border-top:7px solid #1264a3;box-shadow:0 8px 36px #22334412}h1{font-size:38px;line-height:1.16;letter-spacing:-1px;max-width:820px;margin:8px 0 16px}.eyebrow{font-size:12px;letter-spacing:2px;text-transform:uppercase;color:#1264a3;font-weight:700}.subtitle{color:#607586;margin-bottom:36px}.pid{display:inline-block;color:#1264a3;font-size:12px;font-weight:750;min-width:38px}p{margin:22px 0;overflow-wrap:anywhere}#R-1,#R-2{padding:16px 20px;background:#eff6fc;border-left:3px solid #1264a3}figure{margin:30px 0 38px}img{width:100%;height:auto}figcaption{font-size:13px;color:#5b6e7b}.table-wrap{overflow-x:auto;margin:24px 0}table{border-collapse:collapse;width:100%;font-size:14px;font-variant-numeric:tabular-nums}th{background:#e8f1f8;text-align:left;color:#174a70}th,td{padding:11px 13px;border-bottom:1px solid #dce6ee}tr:nth-child(even){background:#f8fafc}footer{border-top:1px solid #dce6ee;margin-top:40px;padding-top:20px;color:#667b8a;font-size:13px}@media(max-width:700px){main{margin:0;padding:26px 18px}h1{font-size:30px}table{font-size:12px}}@media print{body{background:white}main{box-shadow:none;margin:0;padding:12px}figure,table{break-inside:avoid}p{orphans:3;widows:3}}'''
(out/'report.html').write_text('<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Yomitan wildcard performance report</title><style>'+css+'</style><main><div class="eyebrow">Yomitan · performance analysis</div><h1>What does an optional grammar wildcard cost?</h1><div class="subtitle">Small record counts, natural Japanese text, and a real dictionary background · '+meta['date'][:10]+'</div>'+''.join(body)+'<footer>Source timings and reproduction scripts are supplied in evidence.zip. All timing values describe this local experiment.</footer></main></html>')
print(json.dumps({n:{'off':med(n,'off'),'on':med(n,'on'),'added':delta(n)} for n in groups},ensure_ascii=False,indent=2))
