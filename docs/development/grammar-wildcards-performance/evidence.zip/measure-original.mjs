// Standalone report experiment; run from this repository with Node and its Playwright installation.
import {createServer} from 'node:http';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import os from 'node:os';
import JSZip from 'jszip';
import {readFile, writeFile} from 'node:fs/promises';
import path from 'node:path';
import {chromium} from 'playwright';

const output = path.dirname(fileURLToPath(import.meta.url));
const repo = path.resolve(output, '../../..');
const root = path.join(repo, 'ext');
const archivePath = process.argv[2] || path.join(repo, 'dictionaries/jmdict_english.zip');
const archiveBytes = await readFile(archivePath);
const archive = await JSZip.loadAsync(archiveBytes);
const metadata = {date: new Date().toISOString(), commit: execFileSync('git', ['rev-parse', 'HEAD'], {cwd: repo, encoding: 'utf8'}).trim(), cpu: os.cpus()[0].model, node: process.version, dictionaryIndex: JSON.parse(await archive.file('index.json').async('string')), dictionarySha256: createHash('sha256').update(archiveBytes).digest('hex'), rounds: 5, warmupPairsPerRound: 8, timedPairsPerRound: 21, mode: 'simple', backgroundRows: 0};
const server = createServer(async (req, res) => {
    const pathname = new URL(req.url, 'http://localhost').pathname;
    if (pathname === '/') { res.setHeader('Content-Type', 'text/html'); res.end('<!doctype html><title>Wildcard performance</title>'); return; }
    const filename = path.resolve(root, '.' + pathname);
    if (!filename.startsWith(root + '/')) { res.writeHead(403); res.end(); return; }
    try {
        const data = await readFile(filename);
        res.setHeader('Content-Type', filename.endsWith('.js') ? 'text/javascript' : filename.endsWith('.json') ? 'application/json' : 'application/octet-stream');
        res.end(data);
    } catch { res.writeHead(404); res.end(); }
});
await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
const browser = await chromium.launch({headless: true});
try {
    const page = await browser.newPage();
    page.on('pageerror', (e) => console.error(e));
    await page.goto(`http://127.0.0.1:${server.address().port}/`);
    const setup = await page.evaluate(async () => {
        // These experiments do not render dictionary media. Keep the unused media worker idle.
        window.Worker = class {addEventListener() {} terminate() {}};
        const {DictionaryDatabase} = await import('/js/dictionary/dictionary-database.js');
        const {Translator} = await import('/js/language/translator.js');
        const db = new DictionaryDatabase();
        await db.prepare();
        const translator = new Translator(db);
        translator.prepare();
        Object.assign(window, {db, translator});
        window.options = {
            matchType: 'exact', deinflect: true, primaryReading: '', mainDictionary: 'Bench',
            sortFrequencyDictionary: null, sortFrequencyDictionaryOrder: 'ascending',
            removeNonJapaneseCharacters: false, textReplacements: [null],
            enabledDictionaryMap: new Map([['Bench', {index: 0, alias: 'Bench', allowSecondarySearches: false, partsOfSpeechFilter: true, useDeinflections: true}]]),
            excludeDictionaryDefinitions: null, searchResolution: 'letter', language: 'ja', useAllFrequencyDictionaries: false,
        };
        window.clearRows = async () => {
            await new Promise((resolve, reject) => {
                const tx = db._db.transaction(['terms'], 'readwrite');
                const cursor = tx.objectStore('terms').openCursor(IDBKeyRange.lowerBound(window.backgroundLastId, true));
                cursor.onsuccess = () => { const c = cursor.result; if (c) { c.delete(); c.continue(); } };
                tx.oncomplete = resolve; tx.onerror = reject;
            });
        };
        window.addRows = async (n, kind, bytes = 1024) => {
            const rows = [];
            for (let i = 0; i < n; ++i) {
                const expression = kind === 'ordinary' ? `費用が番号${i}円かかる` :
                    kind === 'unrelated' ? `価格${i}～かかる` :
                    kind === 'later' ? `費用が番号${i}～かかる` :
                    kind === 'short' ? `費～終端${i}` :
                    kind === 'hits' || kind === 'twice' || kind === 'mixed' && i === 0 ? '費用が～かかる' :
                    kind === 'natural' ? ['せっかく～のに', 'せっかく～ても', 'せっかく～けれども', 'せっかく～だから', 'せっかく～なら'][i % 5] : `費用が～終端${i}`;
                rows.push({dictionary: kind === 'disabled' ? 'Disabled' : 'Bench', expression,
                    reading: kind === 'twice' ? expression : '', glossary: ['x'.repeat(bytes)],
                    definitionTags: '', termTags: '', rules: '', score: 0, sequence: -1});
            }
            await db.bulkAdd('terms', rows, 0, rows.length);
        };
        window.measure = async (text, enabled, inputSamples = []) => {
            const opts = {...options, enableGrammarWildcards: enabled};
            const samples = [...inputSamples];
            // Count work separately from timed runs so the instrumentation does not inflate timings.
            const stats = {prefixes: 0, returnedPatterns: 0, rawRows: 0, requests: 0, groups: 0, generatedMatches: 0, wildcardMs: 0, dictionaryMs: 0};
            const bulk = db.findTermsBulk;
            const getAll = IDBIndex.prototype.getAll;
            const wildcards = translator._getGrammarWildcardDeinflections;
            translator._getGrammarWildcardDeinflections = async function (deinflections, options) {
                stats.groups = this._groupDeinflectionsByTerm(deinflections).size;
                const start = performance.now();
                const result = await wildcards.call(this, deinflections, options);
                stats.wildcardMs = performance.now() - start;
                stats.generatedMatches = result.length;
                return result;
            };
            db.findTermsBulk = async function (terms, dictionaries, matchType) {
                if (matchType !== 'prefix') { return bulk.call(this, terms, dictionaries, matchType); }
                stats.prefixes = terms.length;
                IDBIndex.prototype.getAll = function (...args) {
                    ++stats.requests;
                    const request = getAll.apply(this, args);
                    request.addEventListener('success', () => { stats.rawRows += request.result.length; });
                    return request;
                };
                const start = performance.now();
                try {
                    const result = await bulk.call(this, terms, dictionaries, matchType);
                    stats.returnedPatterns = result.length;
                    return result;
                } finally {
                    stats.dictionaryMs = performance.now() - start;
                    IDBIndex.prototype.getAll = getAll;
                }
            };
            try {
                const result = await translator.findTerms('simple', text, opts);
                samples.sort((a, b) => a - b);
                return {samplesMs: inputSamples, medianMs: samples[Math.floor(samples.length / 2)], minMs: samples[0], maxMs: samples.at(-1), results: result.dictionaryEntries.length, textLength: text.length, ...stats};
            } finally {
                translator._getGrammarWildcardDeinflections = wildcards;
                db.findTermsBulk = bulk;
                IDBIndex.prototype.getAll = getAll;
                performance.clearMarks(); performance.clearMeasures();
            }
        };
        return navigator.userAgent;
    });
    metadata.browser = setup;
    // Load unchanged JMdict term rows once. All scenarios retain this background.
    for (const filename of Object.keys(archive.files).filter((name) => /^term_bank_\d+\.json$/.test(name)).sort()) {
        const sourceRows = JSON.parse(await archive.file(filename).async('string'));
        metadata.backgroundRows += sourceRows.length;
        await page.evaluate(async (rows) => {
            const terms = rows.map(([expression, reading, definitionTags, rules, score, glossary, sequence, termTags]) => ({
                dictionary: 'JMdict background', expression, reading, definitionTags, rules, score, glossary, sequence, termTags,
            }));
            await db.bulkAdd('terms', terms, 0, terms.length);
        }, sourceRows);
    }
    await page.evaluate(async () => {
        options.enabledDictionaryMap.set('JMdict background', {index: 1, alias: '', allowSecondarySearches: false, partsOfSpeechFilter: true, useDeinflections: true});
        window.backgroundLastId = await new Promise((resolve, reject) => {
            const request = db._db.transaction(['terms'], 'readonly').objectStore('terms').openKeyCursor(null, 'prev');
            request.onsuccess = () => resolve(request.result.key); request.onerror = reject;
        });
    });
    console.log(JSON.stringify(metadata));
    const text = '費用が予想していた金額よりもかなり多くかかる';
    const longText = '費用が当初の見積もりでは十分に考慮されていなかった建物の老朽化に伴う追加工事や資材の値上がりに加えて、専門の業者に依頼するための交通費や宿泊費まで含めると、私たちが去年の会議で予想していた金額よりもはるかに多くかかる。';
    const cases = [];
    const add = (name, n, kind = 'mixed', input = text, bytes = 1024) => cases.push({name, n, kind, text: input, bytes});
    for (const n of [0, 1, 3, 5, 10, 20, 50, 100]) { add(`prefix-${n}`, n); }
    for (const length of [16, 32, 64, 96]) {
        for (const n of [0, 5]) { add(`length-${length}-n${n}`, n, 'misses', longText.slice(0, length)); }
    }
    for (const bytes of [256, 1024, 5120, 20480]) { add(`definition-${bytes}`, 5, 'mixed', text, bytes); }
    add('all-match-5', 5, 'hits');
    add('both-indexes-5', 5, 'twice');
    add('disabled-5', 5, 'disabled');
    add('no-matches-5', 5, 'misses');
    add('unrelated-100', 100, 'unrelated');
    add('natural-5-short', 5, 'natural', 'せっかく楽しみにしていた旅行なのに、台風で中止になってしまった。');
    add('natural-5-long', 5, 'natural', 'せっかく友達と何度も相談しながら半年も前から予定を立てて楽しみにしていた旅行なのに、出発の前日に台風が近づいてきたため中止になってしまった。');
    add('natural-5-repeated', 5, 'natural', 'せっかく遠くから来たのに店が閉まっていて、予約までしたのに誰も連絡をくれなかった。');
    const results = [];
    let seed = 2363;
    const random = () => { seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0; return seed / 4294967296; };
    for (let round = 0; round < metadata.rounds; ++round) {
        const ordered = [...cases];
        for (let i = ordered.length - 1; i > 0; --i) { const j = Math.floor(random() * (i + 1)); [ordered[i], ordered[j]] = [ordered[j], ordered[i]]; }
        for (const scenario of ordered) {
            const result = await page.evaluate(async ({scenario, round, warmup, timed}) => {
                const {n, kind, text, bytes} = scenario;
                await clearRows(); await addRows(n, kind, bytes);
                const samples = [[], []];
                for (let i = 0; i < warmup + timed; ++i) {
                    for (const mode of ((i + round) % 2 ? [1, 0] : [0, 1])) {
                        const start = performance.now();
                        await translator.findTerms('simple', text, {...options, enableGrammarWildcards: Boolean(mode)});
                        if (i >= warmup) { samples[mode].push(performance.now() - start); }
                        performance.clearMarks(); performance.clearMeasures();
                    }
                }
                return {off: await measure(text, false, samples[0]), on: await measure(text, true, samples[1])};
            }, {scenario, round, warmup: metadata.warmupPairsPerRound, timed: metadata.timedPairsPerRound});
            results.push({...scenario, round, ...result});
            console.log(`${round + 1}/${metadata.rounds} ${scenario.name}: off=${result.off.medianMs.toFixed(2)} on=${result.on.medianMs.toFixed(2)} ms`);
            await writeFile(path.join(output, 'results.json'), JSON.stringify({metadata, cases, results}, null, 2));
        }
    }
} finally {
    await browser.close(); server.close();
}
