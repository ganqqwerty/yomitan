# Wildcard report evidence

Run from the Yomitan repository root at commit 26782fbff943af1a79d9d5be59d4080bd0fa15a0:

    node /path/to/extracted/measure.mjs /path/to/jmdict_english.zip
    python3 /path/to/extracted/generate.py /path/to/extracted

Node dependencies and Playwright Chromium must be installed in that checkout.
The Python script needs matplotlib and numpy. The dictionary ZIP is not bundled.
The report records the exact fixture revision and SHA-256.

results.json retains 105 timings per mode per scenario and separate work counters.
summary.csv reports medians of five round medians. stress-results.json is a previous,
different experiment and must not be joined to the new curve.

measure.mjs uses the current repository working directory to resolve dependencies.
The original measured harness derived the repository path from its location under
`docs/development/grammar-wildcards-performance/`; the experiment itself is unchanged.
The original file is included as measure-original.mjs for audit.
